## How to start presentation

```js
npm install
npm start
```